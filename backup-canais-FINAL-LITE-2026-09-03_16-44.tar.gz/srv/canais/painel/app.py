from flask import Flask, request, redirect
from pathlib import Path
from datetime import datetime
import json
import subprocess
import re
import os

app = Flask(__name__)

from clientes import registar_clientes
registar_clientes(app)

BASE = Path("/srv/canais")
ENTRADA = BASE / "entrada"
CONFIG = BASE / "config.json"

def carregar_arquivos():
    cfg = carregar_config()
    listas = cfg.get("listas", {})

    mapa = {
        "MEO SAT": "meo_sat",
        "NOS SAT": "nos_sat",
        "MEO CABO": "meo_terrestre",
        "NOS CABO": "nos_cabo",
    }

    arquivos = {}
    for titulo, chave in mapa.items():
        item = listas.get(chave, {})
        nome = item.get("nome", "").strip()
        if item.get("ativo", False) and nome:
            arquivos[titulo] = ENTRADA / nome

    return arquivos

def carregar_config():
    try:
        return json.loads(CONFIG.read_text())
    except:
        return {
            "box_mestre_ip": "",
            "box_mestre_ssh_port": 22,
            "box_mestre_user": "root"
        }

def contar_canais(path):
    if not path.exists():
        return 0
    return sum(
        1 for linha in path.read_text(errors="ignore").splitlines()
        if linha.startswith("#SERVICE") and "64:" not in linha
    )

def data_ficheiro(path):
    if not path.exists():
        return "Sem ficheiro"
    return datetime.fromtimestamp(
        path.stat().st_mtime
    ).strftime("%d/%m/%Y %H:%M")

def contar_picons(path):
    if not path.exists():
        return 0
    return len(list(path.glob("*.png")))

def estado_vpn():
    r = subprocess.run(
        ["systemctl", "is-active", "openvpn-client@canais"],
        capture_output=True,
        text=True
    )
    ligada = r.stdout.strip() == "active"

    ip = ""
    if ligada:
        r = subprocess.run(
            ["ip", "-4", "addr", "show", "tun0"],
            capture_output=True,
            text=True
        )
        for linha in r.stdout.splitlines():
            linha = linha.strip()
            if linha.startswith("inet "):
                ip = linha.split()[1].split("/")[0]
                break

    return ligada, ip


def estado_sync():
    f = Path("/tmp/canais-sync.status")
    if not f.exists():
        return "PRONTO"
    return f.read_text(errors="ignore").strip()



def estado_auto_vps():
    try:
        r = subprocess.run(
            ["systemctl", "is-enabled", "canais-auto.timer"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True
        )
        ligado = r.stdout.strip() == "enabled"

        hora = "01:20"
        dias = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]

        f = Path("/etc/systemd/system/canais-auto.timer")
        if f.exists():
            txt = f.read_text(errors="ignore")

            m = re.search(r"OnCalendar=(.*?)\s+([0-2][0-9]:[0-5][0-9]):[0-5][0-9]", txt)
            if m:
                parte_dias = m.group(1).strip()
                hora = m.group(2)

                if parte_dias == "*-*-*":
                    dias = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]
                else:
                    dias = [d for d in parte_dias.split(",") if d]

        return ligado, hora, dias
    except:
        return False, "01:20", ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]


def estado_abm(cfg):
    try:
        r = subprocess.run(
            [
                "ssh",
                "-p", str(cfg["box_mestre_ssh_port"]),
                "-o", "BatchMode=yes",
                "-o", "ConnectTimeout=4",
                f'{cfg["box_mestre_user"]}@{cfg["box_mestre_ip"]}',
                "grep -E '^config\\.autobouquetsmaker\\.(schedule|scheduletime)=' /etc/enigma2/settings"
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=6
        )

        ligado = False
        hora = "01:00"

        for linha in r.stdout.splitlines():
            if linha.startswith("config.autobouquetsmaker.schedule="):
                ligado = linha.split("=",1)[1].strip().lower() == "true"

            elif linha.startswith("config.autobouquetsmaker.scheduletime="):
                valor = linha.split("=",1)[1].strip()
                h, m = valor.split(":")
                hora = f"{int(h):02d}:{int(m):02d}"

        return ligado, hora

    except:
        return False, "01:00"


@app.route("/vpn", methods=["POST"])
def controlar_vpn():
    acao = request.form.get("acao")

    if acao == "ligar":
        subprocess.run([
            "sudo", "/usr/bin/systemctl",
            "start", "openvpn-client@canais"
        ])

    elif acao == "desligar":
        subprocess.run([
            "sudo", "/usr/bin/systemctl",
            "stop", "openvpn-client@canais"
        ])

    return redirect("/painel/")


@app.route("/atualizar", methods=["POST"])
def atualizar_agora():
    Path("/tmp/canais-sync.status").write_text("ATUALIZANDO\n")

    try:
        log = open("/tmp/canais-sync.log", "w")
        subprocess.Popen(
            ["/usr/local/bin/sincronizar-box.sh"],
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True
        )
    except Exception:
        Path("/tmp/canais-sync.status").write_text("ERRO\n")

    return redirect("/painel/")




@app.route("/preparar-box", methods=["POST"])
def preparar_box():
    ip = request.form.get("ip", "").strip()
    porta = request.form.get("porta", "22").strip()
    user = request.form.get("user", "root").strip()
    password = request.form.get("password", "")

    if not ip or not porta.isdigit() or not user or not password:
        return redirect("/painel/?box=campos")

    # Retirar eventual chave SSH antiga deste IP
    subprocess.run(
        ["ssh-keygen", "-R", ip],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )
    subprocess.run(
        ["ssh-keygen", "-R", f"[{ip}]:{porta}"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    env = os.environ.copy()
    env["SSHPASS"] = password

    cmd = [
        "sshpass", "-e",
        "ssh-copy-id",
        "-i", "/home/ubuntu/.ssh/id_rsa.pub",
        "-p", porta,
        "-o", "StrictHostKeyChecking=accept-new",
        f"{user}@{ip}"
    ]

    r = subprocess.run(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        env=env,
        timeout=40
    )

    # Password deixa de ser necessária a partir daqui
    password = ""

    if r.returncode != 0:
        return redirect("/painel/?box=erro")

    # Confirmar acesso sem password
    teste = subprocess.run(
        [
            "ssh",
            "-p", porta,
            "-o", "BatchMode=yes",
            "-o", "ConnectTimeout=8",
            f"{user}@{ip}",
            "echo LIGACAO_OK"
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        text=True
    )

    if "LIGACAO_OK" not in teste.stdout:
        return redirect("/painel/?box=erro")

    # Só guarda IP/porta/user. Nunca guarda password.
    cfg = {
        "box_mestre_ip": ip,
        "box_mestre_ssh_port": int(porta),
        "box_mestre_user": user
    }
    CONFIG.write_text(json.dumps(cfg, indent=2))

    return redirect("/painel/?box=preparada")


@app.route("/testar-box", methods=["POST"])
def testar_box():
    cfg = carregar_config()
    box_msg = request.args.get("box", "")

    mensagens_box = {
        "preparada": '<span style="color:#22c55e;font-weight:bold">● Nova Box Mestre preparada</span>',
        "ligada": '<span style="color:#22c55e;font-weight:bold">● SSH OK</span>',
        "semligacao": '<span style="color:#ef4444;font-weight:bold">● Sem ligação SSH</span>',
        "erro": '<span style="color:#ef4444;font-weight:bold">● Erro ao preparar a box</span>',
        "campos": '<span style="color:#f59e0b;font-weight:bold">● Preenche todos os campos</span>'
    }

    box_status = mensagens_box.get(box_msg, "")

    r = subprocess.run(
        [
            "ssh",
            "-p", str(cfg["box_mestre_ssh_port"]),
            "-o", "BatchMode=yes",
            "-o", "ConnectTimeout=8",
            f'{cfg["box_mestre_user"]}@{cfg["box_mestre_ip"]}',
            "echo LIGACAO_OK"
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        text=True
    )

    if "LIGACAO_OK" in r.stdout:
        return redirect("/painel/?box=ligada")

    return redirect("/painel/?box=semligacao")



@app.route("/auto-vps", methods=["POST"])
def auto_vps():
    acao = request.form.get("acao", "")
    hora = request.form.get("hora", "01:20").strip()
    dias = request.form.getlist("dias")

    validos = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]
    dias = [d for d in dias if d in validos]

    if not re.fullmatch(r"(?:[01][0-9]|2[0-3]):[0-5][0-9]", hora):
        return redirect("/painel/")

    if acao == "on":
        if not dias:
            return redirect("/painel/")

        if len(dias) == 7:
            calendario = "*-*-*"
        else:
            calendario = ",".join(dias)

        subprocess.run(
            ["sudo", "/usr/local/sbin/canais-auto-config", "on", hora, calendario],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

    elif acao == "off":
        subprocess.run(
            ["sudo", "/usr/local/sbin/canais-auto-config", "off"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

    return redirect("/painel/")


@app.route("/auto-abm", methods=["POST"])
def auto_abm():
    cfg = carregar_config()

    acao = request.form.get("acao", "")
    hora = request.form.get("hora", "01:00").strip()

    if not re.fullmatch(r"(?:[01][0-9]|2[0-3]):[0-5][0-9]", hora):
        return redirect("/painel/")

    h, m = hora.split(":")
    h = str(int(h))
    m = str(int(m))

    valor = "True" if acao == "on" else "False"

    remoto = (
        "sed -i "
        "-e '/^config\\.autobouquetsmaker\\.schedule=/d' "
        "-e '/^config\\.autobouquetsmaker\\.scheduletime=/d' "
        "-e '/^config\\.autobouquetsmaker\\.nextscheduledtime=/d' "
        "/etc/enigma2/settings; "
        f"printf '\\nconfig.autobouquetsmaker.schedule={valor}\\n"
        f"config.autobouquetsmaker.scheduletime={h}:{m}\\n' "
        ">> /etc/enigma2/settings; "
        "killall -9 enigma2 >/dev/null 2>&1 || true"
    )

    subprocess.run(
        [
            "ssh",
            "-p", str(cfg["box_mestre_ssh_port"]),
            "-o", "BatchMode=yes",
            "-o", "ConnectTimeout=6",
            f'{cfg["box_mestre_user"]}@{cfg["box_mestre_ip"]}',
            remoto
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        timeout=10
    )

    return redirect("/painel/")


@app.route("/config", methods=["POST"])
def guardar_config():
    cfg = carregar_config()

    cfg["box_mestre_ip"] = request.form.get("ip", "").strip()
    cfg["box_mestre_ssh_port"] = int(request.form.get("porta", "22"))
    cfg["box_mestre_user"] = request.form.get("user", "root").strip()

    listas = cfg.setdefault("listas", {})

    for chave in ("meo_sat", "nos_sat", "meo_terrestre", "nos_cabo"):
        atual = listas.setdefault(chave, {"ativo": False, "nome": ""})
        atual["ativo"] = request.form.get(chave + "_ativo") == "on"
        atual["nome"] = request.form.get(
            chave + "_nome",
            atual.get("nome", "")
        ).strip()

    CONFIG.write_text(json.dumps(cfg, indent=2) + "\n")
    return redirect("/painel/")


@app.route("/")
def painel():
    cfg = carregar_config()

    abm_ligado, abm_hora = estado_abm(cfg)
    auto_ligado, auto_hora, auto_dias = estado_auto_vps()

    box_msg = request.args.get("box", "")
    mensagens_box = {
        "preparada": '<span style="color:#22c55e;font-weight:bold">● Nova Box Mestre preparada</span>',
        "ligada": '<span style="color:#22c55e;font-weight:bold">● SSH OK</span>',
        "semligacao": '<span style="color:#ef4444;font-weight:bold">● Sem ligação SSH</span>',
        "erro": '<span style="color:#ef4444;font-weight:bold">● Erro ao preparar a box</span>',
        "campos": '<span style="color:#f59e0b;font-weight:bold">● Preenche todos os campos</span>'
    }
    box_status = mensagens_box.get(box_msg, "")
    vpn_ligada, vpn_ip = estado_vpn()
    sync_estado = estado_sync()

    listas = cfg.get("listas", {})
    meo_sat = listas.get("meo_sat", {})
    nos_sat = listas.get("nos_sat", {})
    meo_terrestre = listas.get("meo_terrestre", {})
    nos_cabo = listas.get("nos_cabo", {})

    meo_sat_checked = "checked" if meo_sat.get("ativo") else ""
    nos_sat_checked = "checked" if nos_sat.get("ativo") else ""
    meo_terrestre_checked = "checked" if meo_terrestre.get("ativo") else ""
    nos_cabo_checked = "checked" if nos_cabo.get("ativo") else ""

    meo_sat_nome = meo_sat.get("nome", "")
    nos_sat_nome = nos_sat.get("nome", "")
    meo_terrestre_nome = meo_terrestre.get("nome", "")
    nos_cabo_nome = nos_cabo.get("nome", "")

    if sync_estado == "ATUALIZANDO":
        sync_html = '<span style="color:#f59e0b;font-weight:bold">● A atualizar...</span><meta http-equiv="refresh" content="5">'
    elif sync_estado == "CONCLUIDO":
        sync_html = '<span style="color:#22c55e;font-weight:bold">● Concluído</span>'
    elif sync_estado == "ERRO":
        sync_html = '<span style="color:#ef4444;font-weight:bold">● Erro</span>'
    else:
        sync_html = '<span style="color:#9ca3af;font-weight:bold">● Pronto</span>' 

    cards = ""
    total = 0

    for nome, ficheiro in carregar_arquivos().items():
        n = contar_canais(ficheiro)
        total += n
        cards += f"""
        <div class="card">
            <h2>{nome}</h2>
            <div class="numero">{n}</div>
            <div class="small">canais encontrados</div>
            <div class="data">Atualizado: {data_ficheiro(ficheiro)}</div>
        </div>
        """

    lamedb = ENTRADA / "lamedb"
    geral = contar_picons(BASE / "picons" / "geral")
    privado = contar_picons(BASE / "picons" / "privado")

    return f"""
<!doctype html>
<html lang="pt">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>MEO / NOS</title>
<style>
body {{
    background:#111827;
    color:#f3f4f6;
    font-family:Arial,sans-serif;
    margin:0;
}}
.top {{
    padding:22px 28px;
    background:#0b1220;
    border-bottom:1px solid #374151;
}}
.top h1 {{ margin:0; font-size:25px; }}
.top p {{ margin:6px 0 0; color:#9ca3af; }}
.grid {{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(210px,1fr));
    gap:18px;
    padding:25px;
}}
.card {{
    background:#1f2937;
    border:1px solid #374151;
    border-radius:12px;
    padding:20px;
}}
.card h2 {{ margin:0 0 12px; font-size:17px; }}
.numero {{ font-size:40px; font-weight:bold; }}
.small,.data {{ color:#9ca3af; margin-top:6px; }}
.estado {{ color:#22c55e; font-weight:bold; }}

.config {{
    margin:0 25px 25px;
    background:#1f2937;
    border:1px solid #374151;
    border-radius:12px;
    padding:22px;
}}
.config h2 {{ margin-top:0; }}

input {{
    background:#111827;
    color:white;
    border:1px solid #4b5563;
    border-radius:6px;
    padding:9px;
    margin:5px 15px 5px 5px;
}}

button {{
    background:#2563eb;
    color:white;
    border:0;
    border-radius:7px;
    padding:10px 18px;
    cursor:pointer;
}}
</style>
</head>

<body>

<div class="top">
    <h1>Servidor de Canais MEO / NOS</h1>
    <p><span class="estado">● ATIVO</span> &nbsp; NGINX + Painel porta interna 5003</p>
</div>

<div class="grid">

{cards}

<div class="card">
    <h2>Total</h2>
    <div class="numero">{total}</div>
    <div class="small">referências nos 3 bouquets</div>
</div>

<div class="card">
    <h2>lamedb</h2>
    <div class="estado">{"OK" if lamedb.exists() else "EM FALTA"}</div>
    <div class="data">{data_ficheiro(lamedb)}</div>
</div>

<div class="card">
    <h2>Picons geral</h2>
    <div class="numero">{geral}</div>
    <div class="small">MEO SAT + NOS SAT</div>
</div>

<div class="card">
    <h2>Picons privado</h2>
    <div class="numero">{privado}</div>
    <div class="small">inclui MEO CABO</div>
</div>

</div>

<div class="config">
<h2>VPN desta VPS</h2>

<p>
Estado:
<b style="color:{'#22c55e' if vpn_ligada else '#ef4444'}">
{'● LIGADA' if vpn_ligada else '● DESLIGADA'}
</b>
&nbsp;&nbsp;
IP VPN: <b>{vpn_ip if vpn_ip else '-'}</b>
</p>

<form method="post" action="vpn" style="display:inline">
<input type="hidden" name="acao" value="ligar">
<button type="submit">Ligar VPN</button>
</form>

<form method="post" action="vpn" style="display:inline">
<input type="hidden" name="acao" value="desligar">
<button type="submit">Desligar VPN</button>
</form>

</div>

<div class="config">
<h2>Box Mestre</h2>

<p>{box_status}</p>

<p>Estado da atualização: {sync_html}</p>

<form method="post" action="atualizar" style="margin-bottom:18px;">
    <button type="submit">Atualizar agora</button>
    <span style="margin-left:12px;color:#9ca3af;">
        Busca listas → gera picons → envia para a box
    </span>
</form>
<hr style="border:0;border-top:1px solid #374151;margin:20px 0;">

<form method="post" action="config">
    IP VPN:
    <input name="ip" value="{cfg['box_mestre_ip']}">

    Porta SSH:
    <input name="porta" size="6" value="{cfg['box_mestre_ssh_port']}">

    Utilizador:
    <input name="user" size="10" value="{cfg['box_mestre_user']}">

    <hr style="border:0;border-top:1px solid #374151;margin:18px 0;">

    <h3>Listas da Box Mestre</h3>

    <div style="margin:10px 0;">
        <b>MEO SAT</b><br>
        <label><input type="checkbox" name="meo_sat_ativo" {meo_sat_checked}> Ativo</label><br>
        <input type="text" name="meo_sat_nome" size="55" value="{meo_sat_nome}">
    </div>

    <div style="margin:10px 0;">
        <b>NOS SAT</b><br>
        <label><input type="checkbox" name="nos_sat_ativo" {nos_sat_checked}> Ativo</label><br>
        <input type="text" name="nos_sat_nome" size="55" value="{nos_sat_nome}">
    </div>

    <div style="margin:10px 0;">
        <b>MEO Terrestre</b><br>
        <label><input type="checkbox" name="meo_terrestre_ativo" {meo_terrestre_checked}> Ativo</label><br>
        <input type="text" name="meo_terrestre_nome" size="55" value="{meo_terrestre_nome}">
    </div>

    <div style="margin:10px 0;">
        <b>NOS Cabo</b><br>
        <label><input type="checkbox" name="nos_cabo_ativo" {nos_cabo_checked}> Ativo</label><br>
        <input type="text" name="nos_cabo_nome" size="55" value="{nos_cabo_nome}">
    </div>

    <button type="submit">Guardar</button>
</form>

<form method="post" action="testar-box" style="margin-top:15px;">
    <button type="submit">Testar ligação</button>
</form>

<hr style="border:0;border-top:1px solid #374151;margin:20px 0;">


<hr style="border:0;border-top:1px solid #374151;margin:20px 0;">

<h3>Atualização automática</h3>

<div style="margin-bottom:18px;">
    <b>ABM da Box</b><br>
    Estado:
    <b style="color:{'#22c55e' if abm_ligado else '#ef4444'}">
        {'● LIGADO' if abm_ligado else '● DESLIGADO'}
    </b>

    <form method="post" action="auto-abm" style="margin-top:8px;">
        Hora:
        <input type="time" name="hora" value="{abm_hora}">

        <button type="submit" name="acao" value="on">Ligar / Guardar</button>
        <button type="submit" name="acao" value="off">Desligar</button>
    </form>

    <small style="color:#9ca3af;">
        Atualiza automaticamente os bouquets na Box Mestre
    </small>
</div>

<div style="margin-bottom:20px;">
    <b>VPS / Picons</b><br>
    Estado:
    <b style="color:{'#22c55e' if auto_ligado else '#ef4444'}">
        {'● LIGADO' if auto_ligado else '● DESLIGADO'}
    </b>

    <form method="post" action="auto-vps" style="margin-top:8px;">
        Hora:
        <input type="time" name="hora" value="{auto_hora}">

        <div style="margin:10px 0;">
            <label><input type="checkbox" name="dias" value="Mon" {"checked" if "Mon" in auto_dias else ""}> Seg</label>
            <label><input type="checkbox" name="dias" value="Tue" {"checked" if "Tue" in auto_dias else ""}> Ter</label>
            <label><input type="checkbox" name="dias" value="Wed" {"checked" if "Wed" in auto_dias else ""}> Qua</label>
            <label><input type="checkbox" name="dias" value="Thu" {"checked" if "Thu" in auto_dias else ""}> Qui</label>
            <label><input type="checkbox" name="dias" value="Fri" {"checked" if "Fri" in auto_dias else ""}> Sex</label>
            <label><input type="checkbox" name="dias" value="Sat" {"checked" if "Sat" in auto_dias else ""}> Sáb</label>
            <label><input type="checkbox" name="dias" value="Sun" {"checked" if "Sun" in auto_dias else ""}> Dom</label>
        </div>

        <button type="submit" name="acao" value="on">Ligar / Guardar</button>
        <button type="submit" name="acao" value="off">Desligar</button>
    </form>

    <small style="color:#9ca3af;">
        Busca as listas → gera os picons → envia para a box
    </small>
</div>

<hr style="border:0;border-top:1px solid #374151;margin:20px 0;">

<h3>Clientes</h3>
<a href="/painel/clientes/" style="display:inline-block;background:#22d3ee;color:white;padding:10px 16px;border-radius:7px;text-decoration:none;font-weight:bold;margin-bottom:20px;">Gerir clientes</a>

<h3>Preparar nova Box Mestre</h3>
<p style="color:#9ca3af;">
A password é usada apenas para instalar a chave SSH e não fica guardada.
</p>

<form method="post" action="preparar-box">
    IP VPN:
    <input name="ip" value="{cfg['box_mestre_ip']}">

    Porta SSH:
    <input name="porta" size="6" value="{cfg['box_mestre_ssh_port']}">

    Utilizador:
    <input name="user" size="10" value="{cfg['box_mestre_user']}">

    Password:
    <input type="password" name="password" autocomplete="new-password">

    <button type="submit">Preparar nova Box Mestre</button>
</form>

</div>

</body>
</html>
"""

app.run(host="127.0.0.1", port=5003)
