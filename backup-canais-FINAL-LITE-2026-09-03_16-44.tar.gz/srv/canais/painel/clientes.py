import json
import os
import subprocess
from pathlib import Path
from html import escape
from flask import request, redirect

CLIENTES_FILE = Path("/srv/canais/clientes.json")
STATUS_FILE = Path("/tmp/canais-clientes.status")
UPDATE_SCRIPT = "/usr/local/bin/atualizar-clientes.py"


def carregar():
    try:
        x = json.loads(CLIENTES_FILE.read_text())
        return x if isinstance(x, list) else []
    except Exception:
        return []


def guardar(x):
    CLIENTES_FILE.write_text(
        json.dumps(x, indent=2, ensure_ascii=False)
    )


def registar_clientes(app):

    @app.route("/clientes/")
    def clientes_pagina():
        dados = carregar()
        msg = request.args.get("msg", "")

        mensagens = {
            "adicionado": ("#22c55e", "Cliente preparado e adicionado"),
            "ssh-ok": ("#22c55e", "Ligacao SSH OK"),
            "ssh-erro": ("#ef4444", "Erro na ligacao SSH"),
            "atualizado": ("#22c55e", "Cliente atualizado"),
            "erro-update": ("#ef4444", "Erro ao atualizar cliente"),
            "apagado": ("#22c55e", "Cliente apagado"),
            "alterado": ("#22c55e", "Automatico alterado"),
            "duplicado": ("#f59e0b", "Ja existe um cliente com esse nome"),
            "erro-preparar": ("#ef4444", "Nao foi possivel preparar o cliente"),
            "todos-ok": ("#22c55e", "Todos os clientes foram atualizados"),
            "todos-erro": ("#ef4444", "Houve erro num ou mais clientes"),
            "iniciado": ("#22c55e", "Atualizacao iniciada"),
        }

        aviso = ""
        refresh = ""

        try:
            estado_update = STATUS_FILE.read_text().strip()
        except Exception:
            estado_update = ""

        if estado_update == "ATUALIZANDO":
            aviso = '<p style="color:#f59e0b;font-weight:bold">● Atualizacao em curso...</p>'
            refresh = '<meta http-equiv="refresh" content="5">'

        elif estado_update == "CONCLUIDO":
            aviso = '<p style="color:#22c55e;font-weight:bold">● Atualizacao concluida</p>'

        elif estado_update == "ERRO":
            aviso = '<p style="color:#ef4444;font-weight:bold">● Erro na atualizacao</p>'

        elif msg in mensagens:
            cor, texto = mensagens[msg]
            aviso = f'<p style="color:{cor};font-weight:bold">● {texto}</p>'

        cards = ""

        for c in dados:
            nome = escape(str(c.get("nome", "")))
            ip = escape(str(c.get("ip", "")))
            porta = int(c.get("porta", 22))
            user = escape(str(c.get("user", "root")))
            tipo = escape(str(c.get("tipo", "geral")).upper())
            ativo = bool(c.get("ativo", True))

            estado = (
                '<span class="on">● LIGADO</span>'
                if ativo else
                '<span class="off">● DESLIGADO</span>'
            )

            texto_auto = (
                "Desligar automatico"
                if ativo else
                "Ligar automatico"
            )

            cards += f'''
            <div class="cliente">
                <h3>{nome}</h3>

                <p>
                <b>{tipo}</b> |
                IP VPN: <b>{ip}</b> |
                Porta: <b>{porta}</b> |
                Utilizador: <b>{user}</b>
                <br>
                Automatico: {estado}
                </p>

                <div class="acoes">
                    <form method="post" action="/painel/clientes/testar">
                        <input type="hidden" name="nome" value="{nome}">
                        <button>Testar ligacao</button>
                    </form>

                    <form method="post" action="/painel/clientes/atualizar">
                        <input type="hidden" name="nome" value="{nome}">
                        <button>Atualizar agora</button>
                    </form>

                    <form method="post" action="/painel/clientes/toggle">
                        <input type="hidden" name="nome" value="{nome}">
                        <button>{texto_auto}</button>
                    </form>

                    <form method="post" action="/painel/clientes/apagar"
                          onsubmit="return confirm('Apagar este cliente?')">
                        <input type="hidden" name="nome" value="{nome}">
                        <button>Apagar</button>
                    </form>
                </div>
            </div>
            '''

        if not cards:
            cards = '<p>Ainda nao existem clientes.</p>'

        return f'''<!doctype html>
<html>
<head>
<meta charset="utf-8">\n{refresh}
<title>Clientes</title>

<style>
body {{
    margin:0;
    padding:28px;
    font-family:Arial,sans-serif;
    background:#132445;
    color:white;
}}

.wrap {{
    max-width:1300px;
    margin:auto;
}}

.bloco {{
    background:#263a60;
    border:1px solid #536789;
    border-radius:14px;
    padding:20px;
    margin-bottom:20px;
}}

.cliente {{
    background:#30466d;
    border-radius:12px;
    padding:16px;
    margin:12px 0;
}}

input, select {{
    background:#192b4b;
    color:white;
    border:1px solid #7183a4;
    border-radius:6px;
    padding:9px;
    margin:4px;
}}

button, .botao {{
    background:#22d3ee;
    color:white;
    border:0;
    border-radius:7px;
    padding:10px 15px;
    font-weight:bold;
    cursor:pointer;
    text-decoration:none;
    display:inline-block;
}}

.acoes {{
    display:flex;
    gap:8px;
    flex-wrap:wrap;
}}

.on {{
    color:#22c55e;
    font-weight:bold;
}}

.off {{
    color:#ef4444;
    font-weight:bold;
}}
</style>
</head>

<body>
<div class="wrap">

<a class="botao" href="/painel/">Voltar ao painel</a>

<h1>Clientes</h1>

{aviso}

<div class="bloco">
<h2>Clientes configurados</h2>

{cards}

<form method="post" action="/painel/clientes/atualizar-todos">
<button>Atualizar todos os clientes</button>
</form>
</div>

<div class="bloco">
<h2>Adicionar novo cliente</h2>

<p>
GERAL = MEO SAT + NOS SAT<br>
PRIVADO = inclui tambem MEO CABO
</p>

<p>
A password serve apenas para instalar a chave SSH.
Nao fica guardada.
</p>

<form method="post" action="/painel/clientes/adicionar">

Nome:
<input name="nome" required>

IP VPN:
<input name="ip" required>

Porta SSH:
<input name="porta" value="22" size="6">

Utilizador:
<input name="user" value="root" size="10">

Tipo:
<select name="tipo">
<option value="geral">GERAL</option>
<option value="privado">PRIVADO</option>
</select>

Password:
<input type="password" name="password" required
       autocomplete="new-password">

<button type="submit">Preparar e adicionar</button>

</form>
</div>

</div>
</body>
</html>'''


    @app.route("/clientes/adicionar", methods=["POST"])
    def clientes_adicionar():
        nome = request.form.get("nome", "").strip()
        ip = request.form.get("ip", "").strip()
        porta = request.form.get("porta", "22").strip()
        user = request.form.get("user", "root").strip()
        tipo = request.form.get("tipo", "geral").lower()
        password = request.form.get("password", "")

        if (
            not nome or not ip or not user or not password
            or not porta.isdigit()
            or tipo not in ("geral", "privado")
        ):
            return redirect("/painel/clientes/?msg=erro-preparar")

        dados = carregar()

        if any(x.get("nome") == nome for x in dados):
            return redirect("/painel/clientes/?msg=duplicado")

        subprocess.run(
            ["ssh-keygen", "-R", ip],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        subprocess.run(
            ["ssh-keygen", "-R", f"[{ip}]:{porta}"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        env = os.environ.copy()
        env["SSHPASS"] = password

        try:
            r = subprocess.run(
                [
                    "sshpass", "-e",
                    "ssh-copy-id",
                    "-i", "/home/ubuntu/.ssh/id_rsa.pub",
                    "-p", porta,
                    "-o", "StrictHostKeyChecking=accept-new",
                    f"{user}@{ip}"
                ],
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=40
            )
        except Exception:
            return redirect("/painel/clientes/?msg=erro-preparar")

        password = ""

        if r.returncode != 0:
            return redirect("/painel/clientes/?msg=erro-preparar")

        teste = subprocess.run(
            [
                "ssh",
                "-p", porta,
                "-o", "BatchMode=yes",
                "-o", "ConnectTimeout=8",
                f"{user}@{ip}",
                "echo SSH_OK"
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True
        )

        if "SSH_OK" not in teste.stdout:
            return redirect("/painel/clientes/?msg=erro-preparar")

        dados.append({
            "nome": nome,
            "ip": ip,
            "porta": int(porta),
            "user": user,
            "tipo": tipo,
            "ativo": True
        })

        guardar(dados)

        return redirect("/painel/clientes/?msg=adicionado")


    @app.route("/clientes/testar", methods=["POST"])
    def clientes_testar():
        nome = request.form.get("nome", "")
        dados = carregar()

        c = next(
            (x for x in dados if x.get("nome") == nome),
            None
        )

        if not c:
            return redirect("/painel/clientes/?msg=ssh-erro")

        r = subprocess.run(
            [
                "ssh",
                "-p", str(c.get("porta", 22)),
                "-o", "BatchMode=yes",
                "-o", "ConnectTimeout=8",
                f'{c.get("user","root")}@{c["ip"]}',
                "echo SSH_OK"
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True
        )

        if "SSH_OK" in r.stdout:
            return redirect("/painel/clientes/?msg=ssh-ok")

        return redirect("/painel/clientes/?msg=ssh-erro")


    @app.route("/clientes/atualizar", methods=["POST"])
    def clientes_atualizar():
        nome = request.form.get("nome", "")

        log = open("/tmp/canais-cliente-update.log", "ab")

        subprocess.Popen(
            [UPDATE_SCRIPT, nome],
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True
        )

        log.close()

        return redirect("/painel/clientes/?msg=iniciado")


    @app.route("/clientes/toggle", methods=["POST"])
    def clientes_toggle():
        nome = request.form.get("nome", "")
        dados = carregar()

        for c in dados:
            if c.get("nome") == nome:
                c["ativo"] = not c.get("ativo", True)

        guardar(dados)

        return redirect("/painel/clientes/?msg=alterado")


    @app.route("/clientes/apagar", methods=["POST"])
    def clientes_apagar():
        nome = request.form.get("nome", "")

        dados = [
            c for c in carregar()
            if c.get("nome") != nome
        ]

        guardar(dados)

        return redirect("/painel/clientes/?msg=apagado")


    @app.route("/clientes/atualizar-todos", methods=["POST"])
    def clientes_atualizar_todos():

        log = open("/tmp/canais-clientes-update.log", "ab")

        subprocess.Popen(
            [UPDATE_SCRIPT, "--all"],
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True
        )

        log.close()

        return redirect("/painel/clientes/?msg=iniciado")

